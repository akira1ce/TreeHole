/*
 * @Author: Akira
 * @Date: 2022-11-05 10:44:39
 * @LastEditTime: 2023-02-20 16:52:00
 */
const mongoose = require("mongoose");

const Types = mongoose.Schema.Types;
module.exports = Types;
