/** 免登录白名单 */
const whiteList = ["/login"]

export { whiteList }
