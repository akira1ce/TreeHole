/*
 * @Author: Akira
 * @Date: 2023-02-22 22:10:50
 * @LastEditTime: 2023-02-22 22:12:06
 */
export interface IUser {
  account: string
  role: string
  avator: string
  name: string
  sex: string
  location: string
}
